<?php
session_start();
if (isset($_SESSION['user_id'])) {
    echo "<h1>Welcome to the Student Portal</h1>";
    echo "<a href='logout.php'>Logout</a>";
    echo "<h2>Register for a Class</h2>";
    echo "<form action='enroll.php' method='post'>";
    include 'db.php';
    $courses = $conn->query("SELECT * FROM courses");
    echo "<select name='course_id'>";
    while ($row = $courses->fetch_assoc()) {
        echo "<option value='" . $row['id'] . "'>" . $row['course_name'] . "</option>";
    }
    echo "</select>";
    echo "<button type='submit'>Register</button></form>";
    
    echo "<h2>Your Registered Classes</h2>";
    $user_id = $_SESSION['user_id'];
    $registered_courses = $conn->query("SELECT courses.id, courses.course_name FROM student_courses JOIN courses ON student_courses.course_id = courses.id WHERE student_courses.user_id = $user_id");
    echo "<ul>";
    while ($row = $registered_courses->fetch_assoc()) {
        echo "<li>" . $row['course_name'] . "<form action='drop_course.php' method='post' style='display:inline;'>";
        echo "<input type='hidden' name='course_id' value='" . $row['id'] . "'>";
        echo "<button type='submit'>Drop</button></form></li>";
    }
    echo "</ul>";
} else {
    echo "<h1>Welcome to the Student Registration System</h1>";
    echo "<a href='login.php'>Login</a> | <a href='register.php'>Register</a>";
}
?>