<?php
session_start();
include 'db.php';
if (isset($_POST['course_id']) && isset($_SESSION['user_id'])) {
    $course_id = $_POST['course_id'];
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("DELETE FROM student_courses WHERE user_id = ? AND course_id = ?");
    $stmt->bind_param("ii", $user_id, $course_id);
    if ($stmt->execute()) {
        echo "Course dropped successfully.";
    } else {
        echo "Error dropping course.";
    }
    $stmt->close();
    header("Location: index.php");
    exit();
} else {
    echo "Invalid request.";
}
?>