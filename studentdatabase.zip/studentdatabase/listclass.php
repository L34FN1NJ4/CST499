<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    die("Please log in first.");
}

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT courses.course_name FROM student_courses JOIN courses ON student_courses.course_id = courses.id WHERE student_courses.user_id = $user_id");
while ($row = $result->fetch_assoc()) {
    echo $row['course_name'] . "<br>";
}
?>